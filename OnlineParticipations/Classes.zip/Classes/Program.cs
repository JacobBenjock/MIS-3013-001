﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes
{
    class Program
    {
        static void Main(string[] args)
        {
            TextBox numberOne = new TextBox();
            numberOne.Padding = 4;
            numberOne.ForeColor = ConsoleColor.Yellow;
            numberOne.BackColor = ConsoleColor.Blue;
            numberOne.Text = "Test Test Test";

            TextBox numberTwo = new TextBox();
            numberTwo.Padding = 6;
            numberTwo.ForeColor = ConsoleColor.Red;
            numberTwo.BackColor = ConsoleColor.Black;
            numberTwo.Text = "Another Test";

            numberOne.DisplayText();
            numberTwo.DisplayText();

            Console.ReadKey();





        }
    }
}
